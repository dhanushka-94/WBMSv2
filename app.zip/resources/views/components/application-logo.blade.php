<img src="{{ asset('images/wassip-logo-only.png') }}" alt="WASSIP Logo" {{ $attributes->merge(['class' => 'object-contain']) }}>
